#!/usr/bin/env bash
read -p "Press enter to do Lab 3"
./lab3.sh
read -p "Press enter to do Lab 4"
./lab4.sh
read -p "Press enter to do Lab 5"
./lab5.sh
read -p "Press enter to do Lab 6"
./lab6.sh
read -p "Press enter to do Lab 7"
./lab7.sh
read -p "Press enter to reboot..."
reboot
