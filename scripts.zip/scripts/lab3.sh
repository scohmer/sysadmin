#!/bin/bash
mkdir development
mkdir development/website
mkdir development/website/images
mkdir development/website/js
cp underconstruction.jpg development/website/images/
echo "<h1>This website is currently under construction</h1>" >> development/website/index.html
echo "<img src=\"./images/underconstruction.jpg\">" >> development/website/index.html
mv development/ /
