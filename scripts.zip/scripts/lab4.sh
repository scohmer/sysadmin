#!/bin/bash
useradd -c "Mary Bodine" mbodine
useradd -c "Taylor Dahl" tdahl
useradd -c "Nancy Williams" nwilliams
useradd -c "Craig Hays" chays
useradd -c "Nikki Reed" nreed
useradd -c "Shawn Rubino" srubino
groupadd Leads
groupadd WebDev
groupadd AppDev
usermod --password Pa$$w0rd -a -G Leads,WebDev,AppDev mbodine
usermod --password Pa$$w0rd -a -G Leads,WebDev,AppDev tdahl
usermod --password Pa$$w0rd -a -G WebDev nwilliams
usermod --password Pa$$w0rd -a -G WebDev chays
usermod --password Pa$$w0rd -a -G AppDev nreed
usermod --password Pa$$w0rd -a -G AppDev srubino
echo "%Leads	ALL=(ALL)	ALL" >> /etc/sudoers
chown mbodine:Leads -R /development
chown nwilliams:WebDev -R /development/website
chown nreed:AppDev /development/website/js/
chmod 775 -R /development
