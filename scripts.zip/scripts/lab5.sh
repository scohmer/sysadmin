#!/bin/bash
yum -y update && yum -y upgrade
yum install -y httpd samba samba-client mariadb "@Development Tools" php python
