#!/bin/bash
echo "0 12 * * 1-5 root mydate=\$(date +\"%Y%m%d\") && date >> /var/log/cpu_usage_\$mydate.log && ps aux --sort -%cpu >> /var/log/cpu_usage_\$mydate.log" >> /etc/crontab
systemctl start httpd smb nmb sshd && systemctl enable httpd smb nmb sshd && systemctl status httpd smb nmb sshd
