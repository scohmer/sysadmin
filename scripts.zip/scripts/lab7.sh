#!/bin/bash
nmcli d show | grep IP4
read -p "Enter your IP4.ADDRESS: " netaddr
read -p "Enter your IP4.GATEWAY: " gateway
hostnameReal=$(hostname)
firewall-cmd --permanent --add-service=samba
firewall-cmd --permanent --add-service=samba-client
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https
firewall-cmd --reload
firewall-cmd --list-services
cp /etc/selinux/config /etc/selinux/config.bak
sed -i 's\enforcing\disabled\g' /etc/selinux/config
mv /etc/samba/smb.conf /etc/samba/smb.bak
cat <<EOF >> /etc/samba/smb.conf
[global]

netbios name = $hostnameReal
workgroup = workgroup

[Leads]

path = /development
read only = no

[WebDev]

path = /development/website
read only = no

[AppDev]

path = /development/website/js
read only = no
EOF
pass=Pa\$\$w0rd
(echo $pass; echo $pass) | smbpasswd -a mbodine
(echo $pass; echo $pass) | smbpasswd -a tdahl
(echo $pass; echo $pass) | smbpasswd -a nwilliams
(echo $pass; echo $pass) | smbpasswd -a chays
(echo $pass; echo $pass) | smbpasswd -a nreed
(echo $pass; echo $pass) | smbpasswd -a srubino
cp /etc/httpd/conf/httpd.conf /etc/httpd/conf/httpd.bak
sed -i 's\DocumentRoot "/var/www/html"\DocumentRoot "/development/website"\g' /etc/httpd/conf/httpd.conf
sed -i 's\<Directory "/var/www/html">\<Directory "/development/website">\g' /etc/httpd/conf/httpd.conf
nmcli con modify ens160 ipv4.addr $netaddr
nmcli con modify ens160 ipv4.gateway $gateway
nmcli con modify ens160 ipv4.dns "10.27.3.2 10.25.3.2"
nmcli con modify ens160 ipv4.method manual
nmcli con modify ens160 connection.autoconnect yes
systemctl restart smb nmb httpd NetworkManager
